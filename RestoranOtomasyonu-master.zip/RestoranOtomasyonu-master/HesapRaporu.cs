﻿namespace RestoranOtomasyonu {
    
    
    public partial class HesapRaporu {
        partial class DataTable1DataTable
        {
        }
    }
}
